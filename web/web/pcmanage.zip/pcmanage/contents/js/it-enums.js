
var it_enums={
};

//工单状态
var quesState={
    WaitSolve:1,
    handling:2,
    Solved:3,
    Confirmed:4,
    Marked:5,
    Cancel:6
};

//工单列表
var codeList={
    WaitSolveList:1,
    handlingList:2,
    MyList:3,
    AllList:4,
    ExecList:5,
    pinfenList:6
}